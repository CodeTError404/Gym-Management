package com.gymManagement.memberservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
