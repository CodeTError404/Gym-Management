package com.gymManagement.memberservice.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class MemberRequest {
    @NotNull(message = "Member Name should not be null")
    private String memberName;
    @NotNull
    @Pattern(regexp = "^\\d{10}$",message = "Please enter valid mobile no")
    private String phnNo;
    @Email(message = "Please enter valid email id")
    private String email;
    @NotNull(message = "assigned trainer's id should not be null")
    private Integer assignedTrainerId;
    @NotNull(message = "Membership plan should not be null")
    private Integer membershipPlanId;
}
