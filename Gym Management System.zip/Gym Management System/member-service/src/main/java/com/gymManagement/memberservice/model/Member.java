package com.gymManagement.memberservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;

@Entity
@Table(name="t_member_service")
@NoArgsConstructor
@AllArgsConstructor(staticName = "build")
@Getter
@Setter
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer memberId;
    private String memberName;
    private String phnNo;
    private String email;
    private Integer assignedTrainerId;
    private Integer membershipPlanId;
}
