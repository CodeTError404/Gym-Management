package com.gymManagement.memberservice.controller;

import com.gymManagement.memberservice.dto.MemberRequest;
import com.gymManagement.memberservice.dto.MemberResponse;
import com.gymManagement.memberservice.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/member")
public class MemberController {
    private final MemberService memberService;
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public String addMember(@RequestBody MemberRequest memberRequest){
        Boolean result=memberService.addMember(memberRequest);
        if(result)
            return "Member added successfully";
        else
            return "Invalid Trainer or Membership Plan";
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<MemberResponse> getAllMembers(){
        return memberService.getAllMembers();
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public MemberResponse getById(@PathVariable Integer id){
        return memberService.getById(id);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public MemberResponse updateById(@RequestBody MemberResponse memberResponse,@PathVariable("id") Integer id){
        memberService.updateById(memberResponse,id);
        return memberResponse;
    }
    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Integer id){
        memberService.deleteById(id);
        return "Record Deleted";
    }
}
