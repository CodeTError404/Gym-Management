package com.gymManagement.memberservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberResponse {
    private Integer memberId;
    private String memberName;
    private BigInteger phnNo;
    private String email;
    private Integer assignedTrainerId;
    private Integer membershipPlanId;
}
