package com.gymManagement.memberservice.service;

import com.gymManagement.memberservice.controller.MemberController;
import com.gymManagement.memberservice.dto.MemberRequest;
import com.gymManagement.memberservice.dto.MemberResponse;
import com.gymManagement.memberservice.model.Member;
import com.gymManagement.memberservice.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    private final WebClient webClient;

    public void addMember(MemberRequest memberRequest){
        Member member=new Member();
        member.setMemberName(memberRequest.getMemberName());
        member.setPhnNo(memberRequest.getPhnNo());
        member.setEmail(memberRequest.getEmail());
        member.setMembershipPlanId(memberRequest.getMembershipPlanId());
        member.setAssignedTrainerId(memberRequest.getAssignedTrainerId());

        Integer t_Id=member.getAssignedTrainerId();
   //     Integer m_Id=member.getMembershipPlanId();
        Boolean result1=webClient.get().uri("http://localhost:8082/api/trainer/findInTrainerList/t_Id").retrieve().bodyToMono(Boolean.class).block();
//        Boolean result2=webClient.get().uri("http://localhost:8081/api/membership/findInMembershipList?m_Id").retrieve().bodyToMono(Boolean.class).block();
//
//        int flag=0;
//        if(!result1){
//            flag=1;
//            throw new IllegalArgumentException("Invalid Trainer Id");
//        }
//        if(!result2) {
//            flag=1;
//            throw new IllegalArgumentException("Invalid plan Id");
//        }
//        if(flag==0)
        System.out.println(result1);
            memberRepository.save(member);
    }

    public List<MemberResponse> getAllMembers() {
        List<Member> members=memberRepository.findAll();
        return members.stream().map(this::mapToDto).toList();
    }
    public MemberResponse  mapToDto(Member member) {
        MemberResponse memberResponse = new MemberResponse();
        memberResponse.setMemberId(member.getMemberId());
        memberResponse.setMemberName(member.getMemberName());
        memberResponse.setPhnNo(member.getPhnNo());
        memberResponse.setEmail(member.getEmail());
        memberResponse.setAssignedTrainerId(member.getAssignedTrainerId());
        memberResponse.setMembershipPlanId(member.getMembershipPlanId());
        return memberResponse;
    }

    public MemberResponse getById(Integer trainerId) {
        Member member=memberRepository.findById(trainerId).orElseThrow();
        MemberResponse memberResponse=new MemberResponse();
        memberResponse.setMemberId(member.getMemberId());
        memberResponse.setMemberName(member.getMemberName());
        memberResponse.setPhnNo(member.getPhnNo());
        memberResponse.setEmail(member.getEmail());
        memberResponse.setMembershipPlanId(member.getMembershipPlanId());
        memberResponse.setAssignedTrainerId(member.getAssignedTrainerId());

        return memberResponse;
    }

    public void deleteById(Integer id) {
        memberRepository.deleteById(id);
    }

    public void updateById(MemberResponse memberResponse, Integer id) {
        Member member=memberRepository.findById(id).orElseThrow();
        member.setMemberName(memberResponse.getMemberName());
        member.setPhnNo(memberResponse.getPhnNo());
        member.setEmail(memberResponse.getEmail());
        member.setAssignedTrainerId(memberResponse.getAssignedTrainerId());
        member.setMembershipPlanId(memberResponse.getMembershipPlanId());
    }
}
