package com.gymManagement.memberservice.service;

import com.gymManagement.memberservice.controller.MemberController;
import com.gymManagement.memberservice.dto.MemberRequest;
import com.gymManagement.memberservice.dto.MemberResponse;
import com.gymManagement.memberservice.model.Member;
import com.gymManagement.memberservice.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;
    private final WebClient.Builder webClientBuilder;

    public Boolean addMember(MemberRequest memberRequest){
        Member member=Member
                .build(0, memberRequest.getMemberName(),
                        memberRequest.getPhnNo(),memberRequest.getEmail(),
                        memberRequest.getAssignedTrainerId(),memberRequest.getMembershipPlanId());

        Boolean result1=webClientBuilder.build().get()
                .uri("http://trainer-service/api/trainer/findInTrainerList/"+member.getAssignedTrainerId())
                .retrieve().bodyToMono(Boolean.class).block();
        Boolean result2=webClientBuilder.build().get()
                .uri("http://membership-service/api/membership/findInMembershipList/"+member.getMembershipPlanId())
                .retrieve().bodyToMono(Boolean.class).block();

        if(result1 && result2) {
            memberRepository.save(member);
            return true;
        }
        else
            return false;


    }

    public List<MemberResponse> getAllMembers() {
        List<Member> members=memberRepository.findAll();
        return members.stream().map(this::mapToDto).toList();
    }
    public MemberResponse  mapToDto(Member member) {
        MemberResponse memberResponse = MemberResponse
                .build(member.getMemberId(), member.getMemberName(),member.getPhnNo(),
                        member.getEmail(), member.getAssignedTrainerId(), member.getMembershipPlanId());

        return memberResponse;
    }

    public MemberResponse getById(Integer trainerId) {
        Member member=memberRepository.findById(trainerId).orElseThrow();
        MemberResponse memberResponse=new MemberResponse();
        memberResponse.setMemberId(member.getMemberId());
        memberResponse.setMemberName(member.getMemberName());
        memberResponse.setPhnNo(member.getPhnNo());
        memberResponse.setEmail(member.getEmail());
        memberResponse.setMembershipPlanId(member.getMembershipPlanId());
        memberResponse.setAssignedTrainerId(member.getAssignedTrainerId());

        return memberResponse;
    }

    public void deleteById(Integer id) {
        memberRepository.deleteById(id);
    }

    public void updateById(MemberResponse memberResponse, Integer id) {
        Member member=memberRepository.findById(id).orElseThrow();
        member.setMemberName(memberResponse.getMemberName());
        member.setPhnNo(memberResponse.getPhnNo());
        member.setEmail(memberResponse.getEmail());
        member.setAssignedTrainerId(memberResponse.getAssignedTrainerId());
        member.setMembershipPlanId(memberResponse.getMembershipPlanId());
    }
}
