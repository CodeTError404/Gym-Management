package com.gymManagement.membershipservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembershipServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
