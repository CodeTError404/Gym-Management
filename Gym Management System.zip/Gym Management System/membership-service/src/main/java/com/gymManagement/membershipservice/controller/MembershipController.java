package com.gymManagement.membershipservice.controller;

import com.gymManagement.membershipservice.dto.MembershipRequest;
import com.gymManagement.membershipservice.dto.MembershipResponse;
import com.gymManagement.membershipservice.service.MembershipService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/api/membership")
@RequiredArgsConstructor
public class MembershipController {
    private final MembershipService membershipService;
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MembershipRequest createPlan(@RequestBody @Valid MembershipRequest membershipRequest){
        membershipService.createPlan(membershipRequest);
        return membershipRequest;
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<MembershipResponse> membershipResponseList(){
        return membershipService.membershipResponseList();
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public MembershipResponse updateById(@RequestBody MembershipResponse membershipResponse,@PathVariable("id") Integer id) {
        membershipService.updateById(membershipResponse, id);
        return membershipResponse;
    }
    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Integer id){
        membershipService.deleteById(id);
        return "Record Deleted";
    }

    @GetMapping("/findInMembershipList/{id}")
    public Boolean findInMembershipList(@PathVariable("id") Integer id){
        return membershipService.findInMembershipList(id);
    }
}
