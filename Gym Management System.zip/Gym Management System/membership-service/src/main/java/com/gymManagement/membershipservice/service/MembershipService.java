package com.gymManagement.membershipservice.service;

import com.gymManagement.membershipservice.dto.MembershipRequest;
import com.gymManagement.membershipservice.dto.MembershipResponse;
import com.gymManagement.membershipservice.model.Membership;
import com.gymManagement.membershipservice.repository.MembershipRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
@RequiredArgsConstructor
@Transactional
public class MembershipService {
    private final MembershipRepository membershipRepository;
    public void createPlan(MembershipRequest membershipRequest) {
        Membership membership=new Membership();
        membership.setPlanDescription(membershipRequest.getPlanDescription());
        membership.setPrice(membershipRequest.getPrice());
        membership.setDurationInMonths(membershipRequest.getDurationInMonths());

        membershipRepository.save(membership);
    }

    public List<MembershipResponse> membershipResponseList() {
        List<Membership> memberships= membershipRepository.findAll();
        return memberships.stream().map(this::mapToDto).toList();
    }
    public MembershipResponse mapToDto(Membership membership){
        MembershipResponse membershipResponse=new MembershipResponse();
        membershipResponse.setPlanId(membership.getPlanId());
        membershipResponse.setPlanDescription(membership.getPlanDescription());
        membershipResponse.setPrice(membership.getPrice());
        membershipResponse.setDurationInMonths(membership.getDurationInMonths());
        return  membershipResponse;
    }

    public void deleteById(Integer id) {
        membershipRepository.deleteById(id);

    }

    public void updateById(MembershipResponse membershipResponse, Integer id) {
        Membership membership=membershipRepository.findById(id).orElseThrow();
        membership.setPlanDescription((membershipResponse.getPlanDescription()));
        membership.setPrice((membershipResponse.getPrice()));
        membership.setDurationInMonths((membershipResponse.getDurationInMonths()));
        membershipRepository.save(membership);
    }

    public Boolean findInMembershipList(Integer id) {
        return membershipRepository.findById(id).isPresent();
    }
}
