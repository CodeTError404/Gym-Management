package com.gymManagement.membershipservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MembershipResponse {
    private Integer planId;
    private String planDescription;
    private Double price;
    private Integer durationInMonths;
}
