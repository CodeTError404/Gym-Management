package com.gymManagement.membershipservice.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MembershipRequest {
    @NotNull(message = "Plan Description can't be Null")
    private String planDescription;
    @NotNull(message = "Price can't be Null")
    @Min(value = 1200,message = "Price can't be less than 1200")
    @Max(value=5000,message = "Price can't be more than 5000")
    private Double price;
    @NotNull(message = "Duration can't be Null")
    private Integer durationInMonths;
}
