package com.gymManagement.membershipservice.dto;

import jakarta.persistence.GeneratedValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MembershipRequest {
    private String planDescription;
    private Double price;
    private Integer durationInMonths;
}
