package com.gymManagement.membershipservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="t_member_service")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Membership {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer planId;
    private String planDescription;
    private Double price;
    private Integer durationInMonths;
}
