package com.gymManagement.trainerservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TrainerRequest {
    private String trainerName;
    private BigInteger phnNo;
    private String email;
    private List<String> skillSet;
}
