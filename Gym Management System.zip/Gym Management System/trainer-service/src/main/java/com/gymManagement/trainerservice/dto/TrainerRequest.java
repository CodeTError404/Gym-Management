package com.gymManagement.trainerservice.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TrainerRequest {
    @NotNull(message = "Name can't be Null")
    private String trainerName;
    @NotNull(message = "Phone number can't be Null")
    @Pattern(regexp = "^\\d{10}$",message = "Please enter valid mobile no")
    private String phnNo;
    @Email(message = "Invalid email id")
    private String email;
    @NotNull(message = "skills set can't be Null")
    private List<String> skillSet;
}
