package com.gymManagement.trainerservice.service;

import com.gymManagement.trainerservice.dto.TrainerRequest;
import com.gymManagement.trainerservice.dto.TrainerResponse;
import com.gymManagement.trainerservice.model.Trainer;
import com.gymManagement.trainerservice.repository.TrainerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TrainerService {
    private final TrainerRepository trainerRepository;
    public void addTrainer(TrainerRequest trainerRequest) {
        System.out.println(trainerRequest.getTrainerName());
        Trainer trainer=new Trainer();
        trainer.setTrainerName(trainerRequest.getTrainerName());
        trainer.setPhnNo(trainerRequest.getPhnNo());
        trainer.setEmail(trainerRequest.getEmail());
        trainer.setSkillSet(trainerRequest.getSkillSet());

        trainerRepository.save(trainer);
    }

    public List<TrainerResponse> getAllTrainers() {
        List<Trainer> trainers=trainerRepository.findAll();
        return trainers.stream().map(this::mapToDto).toList();
    }
    public TrainerResponse  mapToDto(Trainer trainer) {
        TrainerResponse trainerResponse=new TrainerResponse();
        trainerResponse.setTrainerId(trainer.getTrainerId());
        trainerResponse.setTrainerName(trainer.getTrainerName());
        trainerResponse.setPhnNo(trainer.getPhnNo());
        trainerResponse.setEmail(trainer.getEmail());
        trainerResponse.setSkillSet(trainer.getSkillSet());
        return trainerResponse;
    }

    public TrainerResponse getById(Integer trainerId) {
        Trainer trainer=trainerRepository.findById(trainerId).orElseThrow();
        TrainerResponse trainerResponse=new TrainerResponse();
        trainerResponse.setTrainerId(trainer.getTrainerId());
        trainerResponse.setTrainerName(trainer.getTrainerName());
        trainerResponse.setPhnNo(trainer.getPhnNo());
        trainerResponse.setEmail(trainer.getEmail());
        trainerResponse.setSkillSet(trainer.getSkillSet());

        return trainerResponse;
    }

    public void deleteById(Integer id) {
        trainerRepository.deleteById(id);
    }

    public void updateById(TrainerResponse trainerResponse, Integer id) {
        Trainer trainer= trainerRepository.findById(id).orElseThrow();
        trainer.setTrainerName(trainerResponse.getTrainerName());
        trainer.setPhnNo(trainerResponse.getPhnNo());
        trainer.setEmail(trainerResponse.getEmail());
        trainer.setSkillSet(trainerResponse.getSkillSet());
        trainerRepository.save(trainer);
    }

    public Boolean findInTrainerList(Integer id) {
        return trainerRepository.findById(id).isPresent();
    }
}
