package com.gymManagement.trainerservice.controller;

import com.gymManagement.trainerservice.dto.TrainerRequest;
import com.gymManagement.trainerservice.dto.TrainerResponse;
import com.gymManagement.trainerservice.service.TrainerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/trainer")
public class TrainerController {
    private final TrainerService trainerService;
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TrainerRequest addTrainer(@RequestBody TrainerRequest trainerRequest){
        trainerService.addTrainer(trainerRequest);
        return trainerRequest;
    }
    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<TrainerResponse> getAllTrainers(){
        return trainerService.getAllTrainers();
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public TrainerResponse getById(@PathVariable Integer id){
        return trainerService.getById(id);
    }


    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public TrainerResponse updateById(@RequestBody TrainerResponse trainerResponse,@PathVariable("id") Integer id){
        trainerService.updateById(trainerResponse,id);
        return trainerResponse;
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Integer id){
        trainerService.deleteById(id);
        return "Record Deleted";
    }

    @GetMapping("/findInTrainerList/{id}")
    public Boolean findInTrainerList(@PathVariable("id") Integer id){
        return trainerService.findInTrainerList(id);
    }
}
