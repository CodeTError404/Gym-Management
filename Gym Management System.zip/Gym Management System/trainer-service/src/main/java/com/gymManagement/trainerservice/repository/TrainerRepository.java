package com.gymManagement.trainerservice.repository;

import com.gymManagement.trainerservice.dto.TrainerResponse;
import com.gymManagement.trainerservice.model.Trainer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainerRepository extends JpaRepository<Trainer, Integer> {
}
